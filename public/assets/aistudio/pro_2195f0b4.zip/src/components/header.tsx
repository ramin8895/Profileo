'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { ArrowUpRight, Globe2, Menu } from 'lucide-react';
import { copy, profile, locales, type Locale } from '@/lib/content';
import { x } from '@/lib/extra';

export function Header({ lang }: { lang: Locale }) {
  const pathname = usePathname();
  const router = useRouter();
  const links = [['work', copy.work], ['about', copy.about], ['experience', copy.experience], ['remote', x.remote]] as const;
  return <header className="site-header" id="top"><div className="container header-inner">
    <Link href={`/${lang}`} className="brand" aria-label={profile.name[lang]}><span className="brand-symbol" dir="ltr">r<span>.</span></span><span className="brand-name" dir="ltr">ramin<span>hamehpour</span></span></Link>
    <nav className="desktop-nav" aria-label={lang === 'fa' ? 'ناوبری اصلی' : lang === 'ja' ? 'メインナビゲーション' : 'Main navigation'}>{links.map(([id,label])=><Link key={id} href={`/${lang}#${id}`}>{label[lang]}</Link>)}</nav>
    <div className="header-actions"><div className="language-switch" aria-label={lang === 'fa' ? 'انتخاب زبان' : lang === 'ja' ? '言語選択' : 'Language selection'}><Globe2 size={14} aria-hidden="true"/>{locales.map(l=><Link key={l} href={pathname.replace(/^\/(fa|en|ja)(?=\/|$)/, `/${l}`)} hrefLang={l} lang={l} aria-label={{fa:'فارسی',en:'English',ja:'日本語'}[l]} aria-current={l===lang?'page':undefined} onClick={(event)=>{if(window.location.hash && !event.ctrlKey && !event.metaKey && !event.shiftKey && !event.altKey) { event.preventDefault(); router.push(pathname.replace(/^\/(fa|en|ja)(?=\/|$)/, '/'+l)+window.location.hash); }}}>{{fa:'فا',en:'EN',ja:'日本語'}[l]}</Link>)}</div><Link className="header-contact" href={`/${lang}#contact`}>{copy.contact[lang]}<ArrowUpRight size={16} aria-hidden="true"/></Link><details className="mobile-menu"><summary aria-label={copy.menu[lang]}><Menu size={21}/></summary><nav>{links.map(([id,label])=><Link key={id} href={`/${lang}#${id}`} onClick={e=>e.currentTarget.closest('details')?.removeAttribute('open')}>{label[lang]}</Link>)}<Link href={`/${lang}#contact`} onClick={e=>e.currentTarget.closest('details')?.removeAttribute('open')}>{copy.contact[lang]}</Link></nav></details></div>
  </div></header>;
}
